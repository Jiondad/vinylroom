# Vinyl Room — Tag Editor Full Save 작업보고서

기준일: 2026-11-22 KST  
판정: **DEVELOPMENT_PASS / NAS_INSTALL_PENDING / PUBLISH_HOLD**

실제 NAS 계약 자료를 받아 native 색인 연결과 설치 패키지를 개발했습니다. Work에서 NAS 명령을 직접 실행할 연결은 없으며, 아래 개발 결과를 NAS 설치·운영 저장 성공으로 보고하지 않습니다. 세 저장 경로의 실제 NAS 연결·관리자 실증이 끝나기 전에는 main/Pages 게시를 보류합니다. 사용자의 기존 설치·실증·게시 승인은 유지됩니다.

## 1. GitHub 결과

- 개발 브랜치: `feature/tag-editor-complete-save-20261122`.
- 소스 커밋: [`0450050b4133a07f787fc1fc80d86de1b9e971f1`](https://github.com/Jiondad/vinylroom/commit/0450050b4133a07f787fc1fc80d86de1b9e971f1).
- 최신 main 통합 기준: `97052a50a3c12b584b0e7e4ad80f12940a7a4045`. Top100 가사 복구와 기존 직접 Tag Editor 이동·고정 검색창을 보존했습니다.
- 신규 native 연결 CI: [44994305619 — SUCCESS, 12/12](https://github.com/Jiondad/vinylroom/actions/runs/44994305619).
- 이전 저장 연결 CI 13건: [44990367794 — SUCCESS](https://github.com/Jiondad/vinylroom/actions/runs/44990367794). 기존 결과 재사용, 재실행하지 않음.
- 이번 main 병합·Pages 배포: **미실행**. 배포 ID 없음.

## 2. 첨부 자료로 확인된 실제 NAS 기준

다음은 사용자 제공 `NAS_FULLSAVE_CONTRACT_READONLY` 결과이며 Work가 NAS에서 직접 다시 측정한 값은 아닙니다. 설치 직전 도구가 CAS 용도로 재확인합니다.

| 현재 설치 파일 | SHA256 |
| --- | --- |
| server.py | `31cdc3ef488d12d4a4d4e5938f69a0a270b260755d018d4a680a5c8b5c266375` |
| tag_cover_http.py | `bf69b6e6b9d2291dcb30e2e8c7e154c3391aeb9d437669be80b7d8ef019b2298` |
| tag_phase2c.py | `0a98c4c73c6973a212d164d7de11da6384e3865aa4df39338a4e3b0064a6d4a5` |
| tag_cover_h.py | `13062756878a789fa3c27e65716a81330953e5f252ddc5234b2bd9d81b06a736` |
| index_engine.py | `66abf0f75eb256e16334631466ba70eac8faa33e196c2e4b671e4c992cb0c81d` |
| catalog_lease.py | `c14e7cee6838c38350cc6ebd5ec9f8203d1353ab1d6f98f59a15d2f7a2218ba2` |

- Rename 모듈은 운영 컨테이너에 없음.
- 기존 track/cover Writer 플래그 true. 신규 full-tags/Rename 플래그 unset.
- 컨테이너 `music-gateway-music-gateway-1`, 사용자 `1026:100`, 루트 파일시스템 읽기 전용. `/music`, `/data`, `/tag-editor-backups`는 RW.
- 기존 서버는 `tag-editor-save-stage-20261122/server_save_qualified_candidate.py`, HTTP는 같은 단계의 `tag_cover_http_save_candidate.py`, 태그/커버는 `tag-editor-phase-h-source` 개별 bind mount입니다.
- 기존 Index는 `artwork-deploy-prep/index_engine.py`, Lease는 `ai-sync-core-stage1/catalog_lease.py` 개별 mount입니다.

기존 Compose 순서를 유지합니다:

1. compose.yaml
2. compose.confidence70-on.json
3. compose.fieldwise-type-on.json
4. compose.type-correction-auto-control.json
5. compose.tag-editor-phase-h.json
6. tag-editor-save-stage-20261122/compose.tag-editor-save.stage.json
7. tag-editor-save-stage-20261122/compose.tag-editor-runtime.stage.json
8. tag-editor-save-stage-20261122/compose.tag-editor-save-on.json

실제 Docker label에서 이 체인을 읽고 원본 파일 해시를 보관합니다. 환경변수·기존 mount·다른 서비스가 바뀌면 HOLD합니다. 비밀 환경변수 원문은 보고서/manifest에 저장하지 않습니다.

## 3. 이번에 완성한 native 연결

현재 Index.enqueue는 비동기 큐 삽입만 지원합니다. 이를 호출하고 바로 Rename 성공으로 처리할 수 없으므로, 정확한 설치 SHA를 고정하여 **enqueue 함수에만** `synchronous=False` 옵션을 추가합니다.

- 기본 호출은 기존 비동기 큐 동작 유지.
- 동기 호출은 앨범 폴더·수동 색인에 한정하고 queue에 등록하지 않음.
- 동일 스레드에서 기존 execute_job을 실행. HTTP의 기존 runtime guard, enqueue의 기존 index_job, execute_job의 기존 전체 Catalog Lease를 유지.
- 새 SQL 갱신 엔진·새 DB·새 백그라운드 스케줄러 없음.
- 실제 native 완료 상태와 오류를 확인하고 UUID/앨범 경로 및 새 파일 상대 경로를 재조회.
- 진행/대기 색인이 있거나 초기 Catalog seed가 완료되지 않았거나 다른 활성 앨범이 범위 안에 있으면 파일 이동 전 HOLD.
- 실패 시 기존 Rename Writer가 파일과 Catalog 경로의 원복을 검증. 미입증 원복은 manual HOLD.

`prepare_native_fullsave.py`는 원본 서버의 기존 configure_save_context 호출에 `index=INDEX`만 연결합니다. 기존 guard와 자격 인자는 유지하며 direct/alias/attribute/상수 exec 형태를 처리합니다. 등록 위치가 없거나 복수이면 HOLD합니다.

현재 NAS 태그 모듈은 GitHub의 과거 파일로 덮어쓰지 않습니다. validate_track_edits, track_write_plan, _make_stage_track, track_write_preflight 4개 함수와 전용 상수만 병합하며 인자 계약을 확인합니다. HTTP는 설치본의 Folder Index prefix를 그대로 보존하고 알려진 저장 확장 경계만 연결합니다. 알 수 없는 추가 확장이 있으면 HOLD합니다.

## 4. 저장 기능별 상태

| 종류 | 개발 및 재사용 | 운영 상태 |
| --- | --- | --- |
| MP3/FLAC 앞표지 | 기존 Phase H Writer 유지. add/replace/remove, SHA/CAS·백업·복구·동일 파일 재조회 재사용 | 기존 ON 자료 보존. 이번 신규 NAS 연결 시험은 미실행 |
| MP3/FLAC 9개 태그 | 이전 전체 필드 Writer·필드별 승인·전용 플래그 유지. ID3v2.3 다중 값/ID3v1/기타 메타데이터·오디오·내장 이미지 보존 검사 재사용 | 신규 설치/자격/ON 대기 |
| 파일명 변환 저장 | 기존 파서와 `%discnumber% - $num(%track%,2). %title%` 유지. 실제 Rename+같은 Lease의 native 색인+Catalog 상대 경로 확인 연결 | 신규 모듈 설치 및 실제 NAS 시험 대기 |

태그 매핑: TITLE→TIT2/title, ARTIST→TPE1/artist, ALBUM→TALB/album, ALBUMARTIST→TPE2/albumartist, DATE→TDRC/date, GENRE→TCON/genre, FEATURING→TXXX:FEATURING/featuring, TRACKNUMBER→TRCK/tracknumber, DISCNUMBER→TPOS/discnumber. 오른쪽은 MP3/FLAC 순서입니다. 공동 아티스트 `A\B`를 임의 분해하지 않습니다.

선택 파일만 저장합니다. 기존 Writer의 256MiB 파일 제한과 MP3/FLAC 범위를 유지하며 제한을 넘는 파일은 HOLD합니다. 폴더 0.jpg를 수정하지 않습니다. Rename에 따른 Catalog 변경은 기존 정식 Index만 수행하며 AI DB와 커서를 직접 변경하지 않습니다.

## 5. 설치·자격·원복 패키지

패키지: `VinylRoom_TagEditor_Native_FullSave_20261122.zip`.

변경/신규 연결 파일:

- tag_native_index.py: native 단일 앨범 동기 색인 adapter.
- prepare_native_fullsave.py: 정확한 NAS 원본 SHA를 기준으로 필요한 함수만 병합.
- nas_native_fullsave_release.py: prepare/check/install/qualify/enable/rollback.
- qualify_native_fullsave.py: NAS 격리 파일의 3종 저장 및 복구 검증.
- tag_cover_http.py: 자격 영수증과 native callback 연결.
- tag_rename_writer.py: 원본 이동 전 native preflight 연결.
- tag_phase2c.py: 이미 개발된 9개 태그 Writer 참조본. 운영본에는 4개 함수만 병합.
- fixture-audio/test.mp3, test.flac: 인위적으로 생성한 짧은 음원. 실제 소장 음원 아님.

실제 NAS 변경 후보는 server/index/HTTP/tag/rename/native 6개 파일입니다. server/index의 최종 후보 SHA는 NAS 원문으로 생성한 `candidate/SOURCE_SHA256.json`에 남습니다. 현재 이 동적 후보 SHA를 미리 만들어냈다고 보고하지 않습니다.

원본 6개는 별도 baseline 폴더로 보관하고 원본 bind 소스는 수정하지 않습니다. 추가 Compose overlay 하나로 후보 파일을 연결합니다. 기존 Cover·Lease 파일은 교체하지 않습니다. Host Python 구버전은 설치 CLI만 실행하며 AST 변환은 기존 컨테이너 Python을 사용합니다.

설치 시 신규 full-tags/Rename은 OFF. 기존 legacy 태그/커버 ON 설정은 보존합니다. 자격 성공 영수증은 현재 8개 파일 SHA, NAS 서비스 UID, 전용 0700 디렉터리/0600 파일 조건이 맞아야 서버가 인정합니다. 전용 플래그만 true여서는 자격이 생기지 않습니다.

상세 명령은 패키지의 `NAS_NATIVE_FULLSAVE_COMMANDS.md`를 사용합니다. 준비 실패 후 install로 넘기지 않도록 `&&`로 연결했습니다. rollback은 원본 Compose 체인으로 복귀하고 Health를 확인합니다. 이는 설정/소스 원복이며 실제 음원 복구는 기존 operation별 restore 경로를 사용합니다. 백업·감사는 삭제하지 않습니다.

## 6. 신규 국소 검증

신규 고유 검사 12건 PASS. CI 로그의 `Ran 12 tests ... OK`를 확인했습니다. 이전 13건과 기존 Phase H·AI·재생·색인·UI 대규모 시험은 재실행하지 않았습니다.

| 신규 연결 범위 | 결과 |
| --- | --- |
| sync enqueue는 같은 스레드에서 완료, queue 0 / 기본 async 유지 | PASS |
| 서버 직접·alias·attribute·embedded exec 등록과 기존 guard 보존 | PASS |
| 서버 0/복수 등록·기준 해시 불일치 차단 | PASS |
| 태그 4개 함수 병합, 비대상 코드 보존 | PASS |
| native 기능 없음/색인 busy 시 차단 | PASS |
| 자격 자료 부재 시 기존 legacy 자격 보존 | PASS |
| 변경 overlay는 2개 플래그·6개 RO 소스만 사용 | PASS |
| 격리 fixture 컨테이너 network none, 운영 저장소 미마운트 구조 | PASS |
| 다른 Compose 환경변수·mount·서비스 보존 | PASS |
| Folder Index prefix 유지, 알 수 없는 후속 확장 차단 | PASS |
| 자격 영수증의 현재 소스 SHA 및 비공개 권한 검사 | PASS |
| 기존 lock read-only 및 최근 jobs read-only idle 검사 | PASS |

이 결과는 새 연결 계약의 비운영 검사입니다. NAS Docker 설치·실제 native 스캐너·관리자 인증을 통과했다고 확대하지 않습니다.

## 7. 실제 NAS 실증 — 아직 미완료

qualify는 동일 NAS 이미지의 실제 Index/Lease·Writer를 사용하지만 운영 `/music`, `/data`를 마운트하지 않습니다. 별도 fixture Catalog·MP3/FLAC에서 전체 태그 저장/restore, 커버 add/replace/remove/restore, Rename/native 색인/restore와 폴더 0.jpg 보존을 검사하도록 작성했습니다. 서버·AI Worker는 기동하지 않습니다.

단, fixture scanner는 시험 파일의 실제 태그만 읽는 대역입니다. **실제 운영 스캐너와 관리자 HTTP의 capability/plan/apply/동일 파일 재조회는 별도 확인이 필요합니다.** 실패한 자격 보고서로 신규 Writer를 ON하지 않습니다.

| 운영 확인 항목 | 이번 결과 |
| --- | --- |
| 실제 설치본 SHA·Compose 계약 | 첨부 자료 확인 완료 |
| 신규 NAS 소스 설치·컨테이너 재생성 | 미실행 |
| 신규 NAS 자격 시험 및 backup/restore | 미실행 |
| 신규 full-tags/Rename 플래그 적용 | 미실행 |
| 실제 Catalog 변경 파일명 재조회 | 미실행 |
| 인증된 관리자 API 실제 저장·재조회 | 미실행 |
| 신규 저장 UI PC/모바일 NAS 조작 | 미실행 |
| main/Pages 게시 | HOLD |

Work 작업에 따른 운영 NAS 음원·DB 쓰기, 설치, 재시작 및 설정 변경은 **0건**입니다. PC/모바일 기존 UI 합격 자료는 재사용하며, 실제 신규 NAS 저장 브라우저 확인은 미완료로 남깁니다.

## 8. 다음 실행과 완료 조건

패키지 준비→check→유지보수 idle 설치→NAS 격리 자격 순서로 실행하여 실제 출력을 확인합니다. 자격 성공 후 enable은 기존 승인 범위이나, 결과 상태 `FLAGS_APPLIED_ADMIN_API_VERIFICATION_PENDING`을 저장 성공으로 보지 않습니다.

마지막으로 기존 관리자 로그인에서 capability, 승인된 별도 시험 대상의 plan/apply, 동일 파일 태그·커버·파일명 및 native Catalog 경로, backup/restore를 확인해야 합니다. 실제 관리자 NAS 연결과 시험 대상이 확인되기 전에는 임의 UUID 또는 원본 음원으로 쓰기 시험하지 않습니다.

세 기능이 모두 실제 연결 PASS한 뒤에만 최신 main을 다시 통합하고 기존 GitHub Pages 절차로 게시합니다. 지금은 프런트엔드 단독 게시나 운영 성공 보고를 하지 않았습니다.
